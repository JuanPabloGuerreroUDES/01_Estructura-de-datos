
package arbol;

import arbol.Nodo;
import java.awt.*;
import javax.swing.*;

public class panelDibujo {
    
public class PanelArbolGrafico extends JPanel {
    private Arbol arbol;

    public PanelArbolGrafico(Arbol arbol) {
        this.arbol = arbol;
        setPreferredSize(new Dimension(800, 600));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (arbol.getRaiz() != null) {
            dibujar(g, arbol.getRaiz(), getWidth() / 2, 30, getWidth() / 4);
        }
    }

    private void dibujar(Graphics g, Nodo nodo, int x, int y, int separacion) {
        g.setColor(Color.BLACK);
        g.fillOval(x - 15, y - 15, 30, 30);
        g.setColor(Color.WHITE);
        g.drawString(nodo.getDato(), x - 7, y + 5);

        if (nodo.getIzquierda() != null) {
            int xIzq = x - separacion;
            int yIzq = y + 50;
            g.setColor(Color.BLACK);
            g.drawLine(x, y, xIzq, yIzq);
            dibujar(g, nodo.getIzquierda(), xIzq, yIzq, separacion / 2);
        }

        if (nodo.getDerecha() != null) {
            int xDer = x + separacion;
            int yDer = y + 50;
            g.setColor(Color.BLACK);
            g.drawLine(x, y, xDer, yDer);
            dibujar(g, nodo.getDerecha(), xDer, yDer, separacion / 2);
        }
    }
}

}  
    
    
