package arbol;
import arbol.Nodo;
import java.util.LinkedList;
import java.util.Queue;

public class Arbol {
	private Nodo raiz;
        private String cad="";
        private int cont=0;
        
        public Arbol() {
        this.raiz = null;
        }
        public Nodo getRaiz() {
    return raiz;
      }
        
        
	public Arbol(String dato) {
		raiz=new Nodo(dato);
		raiz.setIzquierda(null);
		raiz.setDerecha(null);
                
	}

         

	public void insertarIzquierda(String dato, Nodo ref) {
		if(ref!=null) {
			Nodo nuevo=new Nodo(dato);
			ref.setIzquierda(nuevo);
		}
	 }
	 public void insertarDerecha(String dato, Nodo ref) {
		 if(ref!=null) {
				Nodo nuevo=new Nodo(dato);
				ref.setDerecha(nuevo);
		 }
	 }
	 public String preOrden(Nodo ref) {
		 if(ref!=null) {
                        if(ref==raiz){
                            cad="";
                        }
                     	cad=cad+" "+ref.getDato(); 
                        preOrden(ref.getIzquierda());
			preOrden(ref.getDerecha());
		 }
                 return cad; 
	 }
	 public String inOrden(Nodo ref) {
		 if(ref!=null) {
                        if(ref==raiz){
                            cad="";
                        }
			inOrden(ref.getIzquierda());
			cad=cad+" "+ref.getDato(); 
                        inOrden(ref.getDerecha());
		 }
            return cad; 
	 }
	 public String posOrden(Nodo ref) {
		 if(ref!=null) {
			if(ref==raiz){
                            cad="";
                        }
			
                        posOrden(ref.getIzquierda());
			posOrden(ref.getDerecha());
			cad=cad+" "+ref.getDato(); 
		 }
                 return cad; 
	 }
         
        public String invPreOrden(Nodo ref) {
		 if(ref!=null) {
                        if(ref==raiz){
                            cad="";
                        }
                     	cad=cad+" "+ref.getDato(); 
                        invPreOrden(ref.getDerecha());
                        invPreOrden(ref.getIzquierda());
		 }
                 return cad; 
	}
        
        public String invInOrden(Nodo ref) {
		 if(ref!=null) {
                        if(ref==raiz){
                            cad="";
                        }
			invInOrden(ref.getDerecha());
			cad=cad+" "+ref.getDato(); 
                        invInOrden(ref.getIzquierda());
		 }
            return cad; 
	 }
        
        public String invPosOrden(Nodo ref) {
		 if(ref!=null) {
			if(ref==raiz){
                            cad="";
                        }
			
			invPosOrden(ref.getDerecha());
                        invPosOrden(ref.getIzquierda());
			cad=cad+" "+ref.getDato(); 
		 }
                 return cad; 
	 }
        
   public String grado(Nodo ref) {
    if (ref != null) {
        if (ref == raiz) {
            cad = "";
        }
        int cont = 0;
        if (ref.getIzquierda() != null) cont++;
        if (ref.getDerecha() != null) cont++;

        cad += "Nodo: " + ref.getDato() + "\nGrado: " + cont + "\n=====================\n";
        grado(ref.getIzquierda());
        grado(ref.getDerecha());
    }
    return cad;
}
     

// Método auxiliar para contar nodos descendientes del nodo actual
public String peso(Nodo ref) {
    if (ref != null) {
        if (ref == raiz) {
            cad = "";
        }
        int cantidad = pesoAux(ref); // Cuenta descendientes (incluyéndose)
        cad += "Nodo: " + ref.getDato() + "\nPeso: " + cantidad + "\n=====================\n";

        peso(ref.getIzquierda());
        peso(ref.getDerecha());
    }
    return cad;
}

private int pesoAux(Nodo ref) {
    if (ref == null) return 0;
    return 1 + pesoAux(ref.getIzquierda()) + pesoAux(ref.getDerecha());
}
        
         
     public void insertarEnOrden(String dato) {
    Nodo nuevo = new Nodo(dato);
    if (raiz == null) {
        raiz = nuevo;
        return;
    }

    Queue<Nodo> cola = new LinkedList<>();
    cola.add(raiz);

    while (!cola.isEmpty()) {
        Nodo actual = cola.poll();

        if (actual.getIzquierda() == null) {
            actual.setIzquierda(nuevo);
            break;
        } else {
            cola.add(actual.getIzquierda());
        }

        if (actual.getDerecha() == null) {
            actual.setDerecha(nuevo);
            break;
        } else {
            cola.add(actual.getDerecha());
        }
    }
     }
     public String buscarPadre(String dato) {
    if (raiz == null || raiz.getDato().equals(dato)) {
        return "El nodo es la raíz o el árbol está vacío, no tiene padre.";
    }

    return buscarPadreRec(raiz, dato);
}

private String buscarPadreRec(Nodo actual, String dato) {
    if (actual == null) {
        return "Nodo no encontrado.";
    }

    if ((actual.getIzquierda() != null && actual.getIzquierda().getDato().equals(dato)) ||
        (actual.getDerecha() != null && actual.getDerecha().getDato().equals(dato))) {
        return "El padre del nodo " + dato + " es: " + actual.getDato();
    }

    String izquierda = buscarPadreRec(actual.getIzquierda(), dato);
    if (!izquierda.equals("Nodo no encontrado.")) return izquierda;

    String derecha = buscarPadreRec(actual.getDerecha(), dato);
    return derecha;
}
  public boolean buscarNodo(String dato) {
    return buscarNodoRec(raiz, dato);
}

private boolean buscarNodoRec(Nodo actual, String dato) {
    if (actual == null) return false;
    
    if (actual.getDato().equals(dato)) return true;

    return buscarNodoRec(actual.getIzquierda(), dato) || buscarNodoRec(actual.getDerecha(), dato);
}   
    public boolean podar(String dato) {
    if (raiz == null) return false;

    // Si el nodo a podar es la raíz
    if (raiz.getDato().equals(dato)) {
        raiz = null;
        return true;
    }

    return podarRec(raiz, dato);
}

private boolean podarRec(Nodo actual, String dato) {
    if (actual == null) return false;

  
    if (actual.getIzquierda() != null && actual.getIzquierda().getDato().equals(dato)) {
        actual.setIzquierda(null);
        return true;
    }

   
    if (actual.getDerecha() != null && actual.getDerecha().getDato().equals(dato)) {
        actual.setDerecha(null);
        return true;
    }

   
    return podarRec(actual.getIzquierda(), dato) || podarRec(actual.getDerecha(), dato);
}

public void borrarArbol() {
    raiz = null;
}


public boolean insertarABB(String dato) {
  
    if (raiz == null) {
        raiz = new Nodo(dato);
        return true;
    } else {
        return insertarRec(raiz, dato);
    }
}

private boolean insertarRec(Nodo actual, String dato) {
    int comp = dato.compareTo(actual.getDato());

    if (comp == 0) {
        return false; // Ya existe
    } else if (comp < 0) {
        if (actual.getIzquierda() == null) {
            actual.setIzquierda(new Nodo(dato));
            return true;
        } else {
            return insertarRec(actual.getIzquierda(), dato);
        }
    } else {
        if (actual.getDerecha() == null) {
            actual.setDerecha(new Nodo(dato));
            return true;
        } else {
            return insertarRec(actual.getDerecha(), dato);
        }
    }
}
    

public String mostrarArbol() {
    StringBuilder sb = new StringBuilder();
    mostrarArbolRec(raiz, sb, 0);
    return sb.toString();
}

private void mostrarArbolRec(Nodo nodo, StringBuilder sb, int nivel) {
    if (nodo == null) return;

    mostrarArbolRec(nodo.getDerecha(), sb, nivel + 1);

    for (int i = 0; i < nivel; i++) {
        sb.append("    ");
    }
    sb.append(nodo.getDato()).append("\n");

    mostrarArbolRec(nodo.getIzquierda(), sb, nivel + 1);
}


  public void unirArboles(Arbol otro) {
    if (otro == null || otro.raiz == null) {
        return; // Nada que unir
    }

    unirRecursivo(otro.raiz);
}

private void unirRecursivo(Nodo nodo) {
    if (nodo != null) {
        insertarABB(nodo.getDato()); // Reutiliza tu método de inserción ABB
        unirRecursivo(nodo.getIzquierda());
        unirRecursivo(nodo.getDerecha());
    }
}
public int sumarNodos(Nodo ref) {
    if (ref == null) return 0;
    int valor = 0;
    try {
        valor = Integer.parseInt(ref.getDato());
    } catch (NumberFormatException e) {
        valor = 0;
    }
    return valor + sumarNodos(ref.getIzquierda()) + sumarNodos(ref.getDerecha());
}

public int contarNodos(Nodo ref) {
    if (ref == null) return 0;
    return 1 + contarNodos(ref.getIzquierda()) + contarNodos(ref.getDerecha());
}

public int obtenerMinimo(Nodo ref) {
    while (ref.getIzquierda() != null) {
        ref = ref.getIzquierda();
    }
    return Integer.parseInt(ref.getDato());
}

public int obtenerMaximo(Nodo ref) {
    while (ref.getDerecha() != null) {
        ref = ref.getDerecha();
    }
    return Integer.parseInt(ref.getDato());
}

public String recorridoPorNiveles() {
    StringBuilder resultado = new StringBuilder();
    if (raiz == null) {
        return "El arbol esta vacio.";
    }

    Queue<Nodo> cola = new LinkedList<>();
    cola.add(raiz);

    while (!cola.isEmpty()) {
        Nodo actual = cola.poll();
        resultado.append(actual.getDato()).append(" ");

        if (actual.getIzquierda() != null) {
            cola.add(actual.getIzquierda());
        }
        if (actual.getDerecha() != null) {
            cola.add(actual.getDerecha());
        }
    }

    return resultado.toString();
}

public int altura(Nodo nodo) {
    if (nodo == null) return -1;
    return 1 + Math.max(altura(nodo.getIzquierda()), altura(nodo.getDerecha()));
}
 
public int contarHojas(Nodo nodo) {
    if (nodo == null) return 0;
    if (nodo.getIzquierda() == null && nodo.getDerecha() == null) return 1;
    return contarHojas(nodo.getIzquierda()) + contarHojas(nodo.getDerecha());
}
   
public boolean esCompleto(Nodo raiz) {
    if (raiz == null) return true;
    Queue<Nodo> cola = new LinkedList<>();
    cola.add(raiz);
    boolean encontradoHueco = false;

    while (!cola.isEmpty()) {
        Nodo actual = cola.poll();

        if (actual.getIzquierda() != null) {
            if (encontradoHueco) return false;
            cola.add(actual.getIzquierda());
        } else {
            encontradoHueco = true;
        }

        if (actual.getDerecha() != null) {
            if (encontradoHueco) return false;
            cola.add(actual.getDerecha());
        } else {
            encontradoHueco = true;
        }
    }
    return true;
}
 public boolean esLleno(Nodo nodo) {
    if (nodo == null) return true;
    if (nodo.getIzquierda() == null && nodo.getDerecha() == null) return true;
    if (nodo.getIzquierda() != null && nodo.getDerecha() != null)
        return esLleno(nodo.getIzquierda()) && esLleno(nodo.getDerecha());
    return false;
}
}



         
         

